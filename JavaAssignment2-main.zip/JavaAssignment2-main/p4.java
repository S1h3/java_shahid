package com.jit.thirdsem;

public class p4 {
	int a=10;
	static int x=100;
	public static void test1() {
		System.out.println("from static of p4");
	}
  
}
