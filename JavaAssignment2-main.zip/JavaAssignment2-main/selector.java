package com.jit.thirdsem;

public class selector {

	public static void main(String[] args) {
		int selector=4;
		switch(selector) {
		case 1 :{
			System.out.println("case1");
			break;
		}
		case 2 :{
			System.out.println("case 2");
			break;
		}
		case 3 :{
			System.out.println("case 3");
			break;
		}
		default :{
			System.out.println("default");
			
		}

	}
	}
}
