package com.jit.thirdsem;

public class primitivetypes {
	 public static void main(String[] args) {
	        int i = 10;
	        float f = 23.01f;
	        char c = 'D';
	        boolean b = true;
	        double d = 123e-100;
	        
	        System.out.println("int i value is " + i);
	        System.out.println("float f value is " + f);
	        System.out.println("char c value is " + c);
	        System.out.println("boolean b value is " + b);
	        System.out.println("double d value is " + d);
	 }


}
